# AMPLOP V13 — Cross-template QA / reference implementation

## Scope and outcome
V13 is a patched standalone HTML editor built directly from V12, not a production SaaS. All five template source files are retained. 48 regression assertions (V12 suite) and 73 additional assertions (V13 suite) passed on Chromium. Counts are assertions, not unique features or complete security coverage.

## Deliverables
- `amplop-studio-v13.html`: standalone preview. Open in Chrome from a local file; draft storage availability depends on browser/origin.
- `studio-shell.html`, `studio.js`, `engine.js`, `shared.js`, `typography.js`, `audio-runtime.js`, `templates/`, `assets/`, `invitation.json`, `registry.json`: reference sources.
- `build_studio.py`: deterministic local HTML assembly (`python build_studio.py`).
- `test_regression.py` and `test_v13.py`: Playwright Python suites, requiring installed Chromium and Playwright. Run after building. No real customer data.
- `REGRESSION_V12.txt`, `QA_V13.txt`: actual results.

## Fixed issues and verification
1. Asset reference replacement ran after interpolating customer strings, changing legitimate text like `assets/portrait.webp`. Move replacement before interpolation. Test literal asset-like text and escaped markup in every template.
2. Pending image decode could write into a reset or superseded draft. Per-slot upload epochs invalidate stale operations on new selection, reset or restore-default. Controlled delayed decoder regression verifies reset.
3. Adjusting volume during pause fade could cancel the pause callback and leave playback active. Only cancel a fade when playback intent is active. Verified on every template.
4. Audio control panel was outside the gate's modal focus scope. Hide and make inert until gate opens; verify each template and replay.
5. Reject non-string IDs and years earlier than 1900 to avoid ambiguous calendar behavior. Keep existing WIB schema and date validation. Explicit prototype constraint, not a production business rule.
6. Restore countdown interval on `pageshow` after `pagehide`. Code change inspected and regression suite run; real back/forward cache behavior still needs a dedicated production browser test.
7. Guard audio input cleanup against stale upload epoch. Code inspection; MP3 invalid/oversize checks passed, rapid overlapping audio uploads not exhaustively tested.

## Music customization
Confirmed: existing editor accepts a decodable MP3 upload, built-in tracks, no music, volume and start-on-open settings; export retains selected music. V13 validates size and supported MIME and attempts media decode. MP3 test only; WAV/OGG/M4A compatibility still browser-dependent. Guest control supports play/pause/mute/volume. Current audio loops continuously; a configurable loop toggle, replacement after publication, and cloud uploads are future production work. Proposed production limit 15 MB is not implemented or approved. Require rights confirmation, server-side MIME/magic byte and duration validation, transcoding, rate/size quotas, tenant-scoped private upload storage, and safe published delivery. Do not ship demos as full-length soundtracks without quality review.

## Release gates / remaining risks
- Native browser storage: HTTP/HTTPS navigation blocked by administrator in this test environment. Regression draft restore uses a storage double; standalone test uses in-memory documents. Test actual reload, quota failures, migration, and cross-page persistence on real origin. Backend RSVP and publish are absent.
- iOS Safari, Android devices, in-app WhatsApp browser, screen readers and touch gestures: not verified. Check user-gesture audio policy, physical mute and iOS volume limitations, reduced-motion and keyboard access.
- Full motion opening/skip/replay verified in standalone Chromium; full suite does not exhaustively test all gallery/drag/story interactions, simultaneous editor and guest audio, rapid audio switching with playback, or memory profiling.
- XSS checks are limited to rendered guest fields and specific invalid data; not a production security audit. Preserve server-side escaping, strict CSP with nonces, authorization and tenant isolation, safe file processing and rate limits in implementation.
- Responsive width checks at 320/390/768/1440 for guest views and editor; long unbroken names, unusual fonts, localization and visual clipping need manual review. No contrast audit, Lighthouse or real Core Web Vitals measurements.
- Fonts use local fallback stacks; WOFF2 licensing and visual approval not finalized. Demo photos fictional. Demo labels and fixed story/photo/event slots must be replaced/refactored for production. Only WIB and same-day ceremony/reception supported.
- No repository audit of original AMPLOP, no production deployment, no payment or database. Do not overwrite existing repository. Audit dependencies and route architecture before integrating.

## Codex execution guidance
Use V13 as the latest source of truth (V5–V12 retained only for history). Inspect existing repository first, preserve functional existing routes, and map shared data/rendering/runtime to the existing framework. Avoid adding dependencies unless necessary. Implement one feature increment with acceptance tests. Do not refactor unrelated code. Obtain final design approval before replacing production pages. Report evidence, actual failing tests, and remaining release gates separately. Never label prototype QA as production-ready.
